#!/bin/bash

sudo ufw enable