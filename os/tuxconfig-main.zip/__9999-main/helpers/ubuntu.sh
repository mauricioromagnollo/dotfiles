#!/bin/bash

function ubuntu-autoinstall-drivers() {
  sudo ubuntu-drivers autoinstall
}