#!/bin/bash

function main() {
  echo "Hello Manjaro!"
}
