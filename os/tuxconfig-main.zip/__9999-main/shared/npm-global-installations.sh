#!/bin/bash

npm install -g create-react-app 
npm install -g create-next-app 
npm install -g @nestjs/cli
npm install -g yo generator-code
npm install -g ts-node
npm install -g expo-cli
npm install -g react-native-cli 
npm install -g nodemon
npm install -g typescript
npm install -g gatsby-cli